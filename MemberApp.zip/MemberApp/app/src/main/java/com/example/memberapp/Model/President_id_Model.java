package com.example.memberapp.Model;

public class President_id_Model{
    String president_id;

    public President_id_Model(){}

    public President_id_Model(String president_id) {
        this.president_id = president_id;
    }

    public String getPresident_id() {
        return president_id;
    }
}

